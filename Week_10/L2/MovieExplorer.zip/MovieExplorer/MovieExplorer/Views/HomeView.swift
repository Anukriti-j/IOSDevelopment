
import SwiftUI
import CoreData

struct HomeView: View {
    @StateObject private var homeViewModel: HomeViewModel
    
    init(context: NSManagedObjectContext) {
        _homeViewModel = StateObject(wrappedValue: HomeViewModel(context: context))
    }
    
    //@FetchRequest(sortDescriptors: [NSSortDescriptor(keyPath: \Movie.released, ascending: false)])
    //private var fetchedMovies: FetchedResults<Movie>
    
    var body: some View {
        NavigationStack {
            if homeViewModel.isloading {
                ProgressView("Loading...")
            } else {
                List {
                    
                    ForEach(homeViewModel.response.movieList) { movie in
                        NavigationLink {
                            // TODO: Why navigation link is getting called even not interacted with cell.
                            DetailView(movie: movie, homeViewModel: homeViewModel)
                        } label: {
                            ListRowView(movie: movie)
                        }
                    }
                    
                    
                }
                .navigationTitle("Movies")
                
            }
            
        }
    }
}
//
//#Preview {
//    HomeView()
//}
