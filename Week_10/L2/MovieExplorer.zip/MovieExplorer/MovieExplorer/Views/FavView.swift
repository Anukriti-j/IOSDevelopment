import SwiftUI

struct FavView: View {
    var body: some View {
        NavigationStack {
            List {
                NavigationLink {
                    Text("detail")
                } label: {
                    Text("fav")
                }

            }
        }
    }
}


