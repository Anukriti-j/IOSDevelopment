import SwiftUI
import Kingfisher

struct ListRowView: View {
     var movie: MovieData
    
    var body: some View {
        HStack {
            if let imageUrl = movie.poster, let url = URL(string: imageUrl) {
                KFImage(url)
                    .placeholder({
                        ProgressView()
                    })
                    .resizable()
                    .frame(width: 50, height: 50)
                    .clipShape(RoundedRectangle(cornerRadius: 8))
            }
            Text(movie.title)
        }
    }
}
//
//#Preview {
//    ListRowView()
//}
