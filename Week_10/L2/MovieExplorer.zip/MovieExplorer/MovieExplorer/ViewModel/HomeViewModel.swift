import Foundation
import SwiftUI
import CoreData

@MainActor
class HomeViewModel: ObservableObject {
    @Published var movieList: [APIResponse] = []
   @Published var moviesFromAPI: [MovieData] = []
    //@Published var moviesFromCore: [Movie] = []
    @Published var movieItem: MovieAPIitem = MovieAPIitem(title: "", rated: "", released: "", genre: "", poster: "", ratings: [])
    @Published var isloading: Bool = true
    @Published var isFav: Bool = false
    @Published var context: NSManagedObjectContext
    var response: APIResponse = APIResponse(movieList: [])
    
    let baseUrl = "http://www.omdbapi.com/?apikey=f034da63&s=batman"
    var specificURl = ""
    
    init(context: NSManagedObjectContext) {
        self.context = context
        
        //fetchFromCore()
        
        if movieList.isEmpty {
            Task {
                await fetchMovie(url: baseUrl)
                //SaveToCore(movieAPIItem: movieFromApi ?? nil)
            }
        }
    }
    
    func fetchMovie(url: String) async {
        defer {
            isloading = false
        }
        do {
            response = try await APIService.service.getData(urlString: url)
            
        } catch {
            print("error: \(error)")
        }
    }
    
    func getDetailData(id: String) async {
        do {
            movieItem = try await APIService.service.getData(urlString: "http://www.omdbapi.com/?i=\(id)&apikey=f034da63")
        } catch {
            print("\(error)")
        }
    }
    
//    func fetchFromCore() {
//        let request: NSFetchRequest<Movie> = Movie.fetchRequest()
//        do {
//            moviesFromCore = try context.fetch(request)
//            try context.save()
//        } catch {
//            print("\(error)")
//        }
//    }
    
//    func SaveToCore(movieAPIItem: MovieAPIitem?) {
//        if let movieAPIItem = movieAPIItem {
//            do {
//                let movie = Movie(context: context)
//                movie.title = movieAPIItem.title
//                movie.genre = movieAPIItem.genre
//                movie.released = movieAPIItem.released
//                movie.rated = movieAPIItem.rated
//                try context.save()
//            } catch {
//                print("\(error)")
//            }
//        }   
//    }
}
