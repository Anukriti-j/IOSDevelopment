import SwiftUI
import CoreData

@main
struct MovieExplorerApp: App {
    let coreDataManager = CoreDataManager.shared
    
    var body: some Scene {
        WindowGroup {
            RootView()
                .environment(\.managedObjectContext, coreDataManager.persistentContainer.viewContext)
                
        }
    }
}
