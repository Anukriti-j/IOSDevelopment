import Foundation

struct APIResponse: Codable, Identifiable {
    var id = UUID()
    let movieList : [MovieData]
    
    enum CodingKeys: String, CodingKey {
        case movieList = "Search"
    }
}

struct MovieData: Codable, Identifiable {
    var id = UUID()
    let title: String
    let imdbID: String
    let poster: String?
    
    enum CodingKeys: String, CodingKey {
        case imdbID
        case title = "Title"
        case poster = "Poster"
    }
}
