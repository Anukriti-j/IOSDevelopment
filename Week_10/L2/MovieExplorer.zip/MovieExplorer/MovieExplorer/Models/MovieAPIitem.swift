
import Foundation

struct MovieAPIitem: Codable, Identifiable {
    var id = UUID()
    let title, rated, released: String?
    let genre: String?
    let poster: String?
    let ratings: [Rating]
    
    enum CodingKeys: String, CodingKey {
        case title = "Title"
        case rated = "Rated"
        case released = "Released"
        case genre = "Genre"
        case poster = "Poster"
        case ratings = "Ratings"
    }
}

struct Rating: Codable, Identifiable {
    var id = UUID()
    let source, value: String?
    
    enum CodingKeys: String, CodingKey {
        case source = "Source"
        case value = "Value"
    }
}
