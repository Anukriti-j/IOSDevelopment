import Foundation

enum TabSelection: String, CaseIterable, Identifiable {
    case Home, Favourites
    
    var id: String { self.rawValue }
    
    var tabItemLabel: String {
        switch self {
        case .Home:
            return "Home"
        case .Favourites:
            return "Favourites"
        }
    }
    
    var tabImage: String {
        switch self {
        case .Home:
            return "house"
        case .Favourites:
            return "heart"
        }
    }
}
